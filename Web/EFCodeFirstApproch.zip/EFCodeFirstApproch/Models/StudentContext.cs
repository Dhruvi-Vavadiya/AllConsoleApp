﻿using System.Data.Entity;
namespace EFCodeFirstApproch.Models
    
{
    public class StudentContext : DbContext
    {
        public DbSet<Student> Students { get; set; }
    }
}
